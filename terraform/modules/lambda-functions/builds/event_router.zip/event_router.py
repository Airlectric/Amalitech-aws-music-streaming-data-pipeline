import json
import os
from urllib.parse import unquote_plus

import boto3

sfn = boto3.client("stepfunctions")

STATE_MACHINE_ARN = os.environ["STATE_MACHINE_ARN"]
STREAM_PREFIX = "streams/landing_date="
MANIFEST_PREFIX = "streams/manifests/"


def lambda_handler(event, context):
    detail = event.get("detail", {})
    bucket = detail.get("bucket", {}).get("name", "")
    key = unquote_plus(detail.get("object", {}).get("key", ""))

    if not bucket or not key:
        return {"statusCode": 400, "body": "Missing bucket or key"}

    if not _should_process(key):
        return {"statusCode": 200, "body": "Skipped"}

    landing_date = _extract_landing_date(key)
    execution_input = {
        "bucket": bucket,
        "key": key,
        "landing_date": landing_date,
        "event_time": event.get("time", ""),
        "execution_id": f"{bucket}-{key.replace('/', '-')}-{context.aws_request_id[:8]}",
    }

    response = sfn.start_execution(
        stateMachineArn=STATE_MACHINE_ARN,
        input=json.dumps(execution_input),
    )

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "execution_arn": response["executionArn"],
                "start_date": response["startDate"].isoformat(),
            }
        ),
    }


def _should_process(key):
    return (
        key.startswith(STREAM_PREFIX)
        and key.endswith(".csv")
        and not key.startswith(MANIFEST_PREFIX)
    )


def _extract_landing_date(key):
    marker = "landing_date="
    if marker not in key:
        return ""

    suffix = key.split(marker, 1)[1]
    return suffix.split("/", 1)[0]
